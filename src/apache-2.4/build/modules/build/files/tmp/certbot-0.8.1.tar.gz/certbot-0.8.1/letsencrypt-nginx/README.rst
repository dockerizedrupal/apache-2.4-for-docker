This package is a simple shim for backwards compatibility around
``certbot-nginx``, the Nginx plugin for ``certbot``.
