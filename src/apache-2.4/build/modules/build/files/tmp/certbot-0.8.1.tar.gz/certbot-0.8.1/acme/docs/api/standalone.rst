Standalone
----------

.. automodule:: acme.standalone
   :members:
