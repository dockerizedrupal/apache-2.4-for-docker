:mod:`certbot.log`
----------------------

.. automodule:: certbot.log
   :members:
