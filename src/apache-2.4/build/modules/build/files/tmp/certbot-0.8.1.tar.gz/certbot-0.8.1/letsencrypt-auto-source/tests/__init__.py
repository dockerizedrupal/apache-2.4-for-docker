"""Tests for letsencrypt-auto

Run these locally by saying... ::

    ./build.py && docker build -t lea . && docker run --rm -t -i lea

"""
